#1. Create a greeting for your program.
print("Generador de nombre de banda")
#2. Ask the user for the city that they grew up in.
ciudad = input("En que ciudad te criaste? \n")
#3. Ask the user for the name of a pet.
mascota_nombre = input("Como se llama tu mascota? \n")
#4. Combine the name of their city and pet and show them their band name.
nombre_banda = ciudad + mascota_nombre
print ("El nombre de la banda es " + nombre_banda)

#5. Make sure the input cursor shows on a new line, see the example at:
#   https://band-name-generator-end.appbrewery.repl.run/